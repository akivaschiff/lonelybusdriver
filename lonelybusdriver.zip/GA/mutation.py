def mutate(routeset):
	pass